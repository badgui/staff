package com.eremin.staff.interfaces;

public interface IClickRecycler {
    void clickRecycler(String id);
}
