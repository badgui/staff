package com.eremin.staff.other;

public class ConstantManager {
    public static final String CLICK_RECYCLER = "click_recycler";

    public static final String LAST_NAME = "LAST_NAME";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String FATHER_NAME = "FATHER_NAME";
    public static final String POSITION = "POSITION";
}
